# Green Goods brand kit v3

Dark green (#367D44) is canonical. Native source vectors are retained in source/. Historical Figma green and optional recolors remain available. Website integration files use canonical dark green.

New additions: palette CSS/JSON, Inter and Fraunces font files with OFL license, symbol patterns, and editable SVG templates with rendered PNG references. Graphics and templates are new compositions, not exports of additional Figma board assets.

See templates/README.txt before editing. Application and docs design guides continue to own UI styling. Print CMYK specifications, brand ownership terms, horizontal lockups, photography guidance and the fresh Figma inventory remain open.
