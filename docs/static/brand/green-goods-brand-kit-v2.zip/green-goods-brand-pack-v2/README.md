# Green Goods logo export pack

Start with `primary/dark-green/symbol-square-large` for a prominent square logo, or `primary/dark-green/logo-square-large` for the symbol with the Green Goods name. Each folder contains a scalable SVG and ready-to-use PNGs. `preview.png` compares the main variants.

## Layouts and sizes

| Folder | Framing | PNG sizes |
| --- | --- | --- |
| `symbol-square-original` | Original Figma square; symbol covers about 59% of its width | 64, 128, 256, 500, 512, 750, 1024, 2048 px square |
| `symbol-square-large` | Centered symbol covering 84% of the square width | Same sizes as original |
| `logo-square-standard` | Symbol and name covering 76.8% of the square width | 256, 500, 512, 750, 1024, 2048 px square |
| `logo-square-large` | Symbol and name covering 88% of the square width | Same sizes as standard |
| `logo-wide` | Original landscape frame with symbol above the name | 256, 512, 816, 1224, 1632, 2448, 3264 px wide; height follows the original aspect ratio |

For a 512 px base asset, 1024 px is 2× and 2048 px is 4×. The original 500 px square also has a 750 px export at 1.5×. Wide logos include the original 816 px width and 1.5×, 2×, 3×, and 4× sizes. Use SVG when the destination supports vectors. The lettering is outlined, so the recipient does not need the original font.

## Colors

`primary` contains the three logo colors exported directly from Figma: original green (#3E8E4E), white, and black. It also contains an explicit dark-green variant (#367D44), derived from the dominant opaque color in the current docs logo (`docs/static/img/green-goods-logo.png`). The board’s forest-green palette shade is #367D41; these similar shades remain separately named until the official brand palette is settled. White works on dark backgrounds; black works on light backgrounds.

`palette-extras` contains locally derived color options using the board’s palette: forest green (#367D41), light green (#46A359), sienna (#A0522D), and sky blue (#87CEEB). These are additional export variants, not existing approved logo variants on the board. Only the green vector fills were recolored; the original geometry and subtle overlap shading were preserved.

## Common uses

| Use | Starting asset |
| --- | --- |
| Profile pictures and social avatars | Large square symbol at 512 or 1024 px |
| Square promotional artwork | Large square logo with name at 1024 or 2048 px |
| Website branding, documents, and slides | Wide SVG, or a PNG at least as wide as its displayed size |
| Print production | SVG; confirm final dimensions and printer color requirements |
| Browser favicon | `website-ready/favicon.svg` with `favicon.ico` as a fallback |
| Apple home-screen icon | `website-ready/apple-touch-icon.png` |
| PWA icons | `website-ready/icon-192.png`, `icon-512.png`, and the separate maskable versions |

## Favicons and app icons

All eight colors have a favicon SVG, an ICO containing 16/32/48/64/128/256 px images, and individual PNGs at those sizes. The favicon symbol covers 92% of the frame width for visibility at small sizes. It retains the original symbol geometry and has a transparent background.

`app-icons` contains white-on-green and green-on-white icons at 180, 192, 512, and 1024 px, plus maskable versions at 192 and 512 px. These intentionally have opaque backgrounds. Maskable artwork occupies 65% of the width and was checked against the central safe circle described in [web.dev’s maskable icon guidance](https://web.dev/articles/maskable-icon).

`website-ready` collects the default green favicons and white-on-green app icons. Copy its image files into the site’s public root, then adapt `head-snippet.html` to the actual asset paths. Merge the `icons` array from `icons.manifest.json` into the existing application manifest; that file is an icon fragment, not a complete application manifest. The snippet uses the [standard icon link relation](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Attributes/rel#icon).

## Source and checks

The six original outlined SVGs are in `source`. They came from the [Green Goods Branding board](https://www.figma.com/design/v4nQIhK4MPgWHKs8K8BpfI/Branding). The source node IDs, colors, and exported dimensions are recorded in `export-manifest.json`.

All logo SVGs and PNGs have transparent backgrounds. The preview checkerboards are display backgrounds only. The Figma board requires a Full seat for edits, so reframing and palette variants were produced locally from the original vectors. No application integration is included in this export pack.

`validation.json` records the completed checks: PNG dimensions and transparency, larger-symbol centering and size, opaque app backgrounds, maskable safe-area coverage, and ICO size coverage.
