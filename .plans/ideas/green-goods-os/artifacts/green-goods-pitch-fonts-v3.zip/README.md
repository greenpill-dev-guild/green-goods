# Green Goods pitch fonts, v3 bundle

Fonts referenced by the v3 cover checkpoint (`visual-direction-v3/green-goods-pitch-cover-v3.pptx`).
The PPTX references these families by name and does not embed them. Install nothing automatically;
an editor whose computer lacks them can add these files or accept a substitute, which changes line
wrapping. Deliver audience copies as PDF rendered with these exact files.

Static instances from Google Fonts (static per-weight files, not the variable font):

- `fraunces-normal-400.ttf` (family name `Fraunces`, Regular 400). Copied unchanged from the
  repository at `packages/client/vite/assets/fonts/social/`, fetched on 2026-05-10 from
  `https://fonts.gstatic.com/s/fraunces/v38/6NUh8FyLNQOQZAnv9bYEvDiIdE9Ea92uemAk_WBq8U_9v0c2Wa0K7iN7hzFUPJH58nib1603gg7S2nfgRYIctxujDg.ttf`
- `fraunces-normal-500.ttf` (family name `Fraunces Medium`, usWeightClass 500). Fetched on
  2026-10-10 UTC from
  `https://fonts.gstatic.com/s/fraunces/v38/6NUh8FyLNQOQZAnv9bYEvDiIdE9Ea92uemAk_WBq8U_9v0c2Wa0K7iN7hzFUPJH58nib1603gg7S2nfgRYIchRujDg.ttf`
  (the URL Google Fonts serves for `family=Fraunces:wght@500`). SHA-256
  `0c2fad18ed36cc400041f1e281ee79954a329b345caffc38dfaa3bb8bcef57de`. Downloaded into a session
  scratch directory only; nothing was installed system-wide.
- `inter-normal-400.ttf` (family name `Inter`, Regular 400, 14 pt optical size). Copied unchanged
  from the repository, fetched on 2026-05-10 from
  `https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf`

The italic cut from the v2 bundle is no longer referenced and is omitted here; the v2 bundle keeps it.

Fraunces (Undercase Type) and Inter (Rasmus Andersson) are distributed under the SIL Open Font
License 1.1; see `OFL.txt`. Both fonts' name tables carry `https://scripts.sil.org/OFL`.
